
function IsDigit(str)
{
	var i;

	if (str == "")
		return false;

	i = 0
	if (str.charAt(0) == '-') 
		i = 1

	for (; i < str.length; i++) {
		if (str.charAt(i) < '0' || str.charAt(i) > '9')
			return false;
	}

	return true;
}

function IsDigitIn(str, min, max)
{
	var i;

	if (!IsDigit(str))
		return false;

	if (str >= min && str <= max)
		return true;

	return false;
}

function IsEngString(str)
{
	var i;

	if (str == "")
		return false;

	for (i = 0; i < str.length; i++) {
		if (str.charAt(i) >= 'a' && str.charAt(i) <= 'z' ||
		    str.charAt(i) >= 'A' && str.charAt(i) <= 'Z' ||
		    str.charAt(i) >= '0' && str.charAt(i) <= '9') {
			continue;
		}
		else {
			return false;
		}
	}

	return true;
}

function IsIPAddr(str)
{
	var i, j;
	var ar, tmp;
	var ipstr;

	/* format: x.x.x.x/n */
	ar = str.split("/");
	if (ar.length == 2) {
		if (ar[1] < 0 || ar[1] > 32)
			return false;
		ipstr = ar[0];
	}
	else {
		ipstr = str;
	}

	ar = ipstr.split(".");
	if (ar.length != 4)
		return false;

	for (i = 0; i < ar.length; i++) {
		if (ar[i] == "") return false;

		tmp = ar[i];
		for (j = 0; j < tmp.length; j++) {
			if (tmp.charAt(j) < '0' || tmp.charAt(j) > '9')
				return false;
		}

		if (ar[i] < 0 || ar[i] > 255)
			return false;
	}

	return true;
}

function IsMacAddr(str)
{
	var ar;
	
	ar = str.split(":");
	if (ar.length != 6)
		return false;

	return true;
}

function IP2Int(str)
{
	var ar;
	var ipval;

	ar = str.split(".");
	ipval = ar[0] * 16777216 + ar[1] * 65536 +
		ar[2] * 256 + ar[3];

	return ipval;
}

function IsValidatePort(str)
{
	var ar;

	ar = str.split("-");

	if (ar.length == 1) {
		if (IsDigitIn(ar[0], 1, 65535))
			return true;
	}

	if (ar.length == 2) {
		if (!IsDigitIn(ar[0], 1, 65535))
			return false;
		if (!IsDigitIn(ar[1], 1, 65535))
			return false;
		if (ar[0] > ar[1])
			return false;

		return true;
	}

	return false;
}

function IsNet(str)
{
	var ar;

	ar = str.split("/");
	if (ar.length != 2) return false;
	if (!IsIPAddr(ar[0])) return false;
	if (!IsDigitIn(ar[1], 1, 32)) return false;

	return true;
}

function IsMAC(str)
{
	var ar;

	ar = str.split(":");
	if (ar.length != 6)
		return false;

	for (i = 0; i < ar.length; i++) {
		if (ar[i].length != 1 && ar[i].length != 2)
			return false;

		for (j = 0; j < ar[i].length; j++) {
			var ch = ar[i].charAt(j);

			if (!((ch >= '0' && ch <= '9') || (ch >= 'a' && ch <= 'f') || (ch >= 'A' && ch <= 'F')))
				return false;
		}
	}

	return true;
}

function IsNetmask(str)
{
	if (!IsIPAddr(str))
		return false;

	var n = str.split(".");
	i = 0;
	while (i < 4) {
		if (n[i] == 255)
			i++;
		else break;
	}

	if (i == 4)
		return true;

	if ((n[i] % 2) != 0)
		return false;

	for (j = i + 1; j < 4; j++) {
		if (n[j] != 0)
			return false;
	}

	return true;
}

function TrimAll(str)
{
	var s="";

	for (i = 0; i < str.length; i++) {
		if (str.charAt(i) != ' ') {
			s = s + str.charAt(i);
		}
	}

	return s;
}

function EnableIt(obj, enable)
{
	if (enable) {
		obj.readonly = false;
		obj.style.backgroundColor = 0xffffff;
	}
	else {
		obj.readonly = true;
		obj.style.backgroundColor = 0xd0d0d0;
	}
} 

var sourceOrigin;
var sendwin;
function receiveMessage(win){
	
	if(typeof sourceOrigin != "string") {
		SetDialogPostEvent(function(event){
			//if (event.origin !== "https://192.168.0.199")
			//return;
			if (event.data == 'Hello Panabit') {
				event.source.postMessage('Hi Panabit', event.origin);
				sourceOrigin = event.origin;
			} else {
				var node = event.data.split(":");
				if(node[0] == "data") {
					var ar = node[1].split(",");
					if (ar.length != 2) {
						alert("��Ч�ķ���ֵ");
						return;
					}

					appid = document.getElementsByName("appid")[0];
					appname = document.getElementsByName("appname")[0];
					appid.value = ar[0];
					appname.value = ar[1];
				}
				else
				if (node[0] == "passip") {
					passip = document.getElementsByName("passip")[0];
					passip.value = node[1];
				}
			}
		});

		if(typeof win == "object")
			sendwin = win;
		sendwin.postMessage("Hello Panabit", "*");
		setTimeout(receiveMessage, 1000) ;
	}
}

function ShowDialog(url, args, width, height)
{
	var attr;

	if (window.showModalDialog) {
		attr = "dialogWidth:" + width + "px;" + 
				   "dialogHeight:" + height + "px;" +
				   "edge:raised;status:no;scroll:no;help:no";
		return showModalDialog(url, args, attr);
	}
	else {
		var top  = (window.screen.height - height) / 2;
		var left = (window.screen.width - width) / 2;

		attr =  "top=" + top + ",left=" + left + 
				",width=" + width + ",height=" + height + 
				", modal=yes, alwaysRaised=yes";
		var modal = window.open (url, null, attr); 
		//if(typeof postDialogProce == "function") {
		//	postDialogProce(modal);
		//}
		sourceOrigin = undefined;
		receiveMessage(modal);
	}
	return "NONE";
}

function SetDialogPostEvent(recMsgfuc)
{
	if (typeof recMsgfuc != "function")
		return false;

	if (typeof window.addEventListener != 'undefined') { 
		window.addEventListener("message", recMsgfuc, false);
	} else if (typeof window.attachEvent != 'undefined') { 
		//for ie 
		window.attachEvent('onmessage', recMsgfuc); 
	}
	
	return true;
}

function ShowWindow(url, args, width, height)
{
	var left = (window.screen.width - width) / 2;
	var top  = (window.screen.height - height) / 2 - 50;

	if (args == "")
		args = "scrollbars=1,toolbar=0,menubar=0,status=0,location=0";
	else
		args += ",location=0";

	args += ",top=" + top + ",left=" + left + ",height=" + height + ",width=" + width;
	return window.open(url, "_blank", args);
}

function ShowPage(page)
{
	document.all(page).style.display = "block";
}

function HidePage(page)
{
	document.all(page).style.display = "none";
}

function OnCancel()
{
	window.close();
}


function OnValidateIP(obj, allowEmpty)
{
        obj.value = TrimAll(obj.value);

        if (obj.value == "" && allowEmpty ||
            obj.value != "" && IsIPAddr(obj.value))
        {
                return true;
        }

        alert("��������ȷ��IP��ַ!");
        return false;
}

function OnValidateMask(obj, allowEmpty)
{
        obj.value = TrimAll(obj.value);

        if (obj.value == "" && allowEmpty ||
            obj.value != "" && IsNetmask(obj.value))
        {
                return true;
        }

        alert("��������ȷ����������!");
        return false;
}


function selectApp(appid)
{
	var ar;
	var url;
	var retval;
	var objAppid;
	var objAppname;

	url = "/cgi-bin/Setup/app_select";
	retval = ShowDialog(url, "", 500, 600);
	if (retval == "NONE") return;

	ar = retval.split(",");
	if (ar.length != 2) {
		alert("INV_RETURN");
		return;
	}

	objAppid   = document.getElementsByName("appid")[0];
	objAppname = document.getElementsByName("appname")[0];
	objAppid.value = ar[0];
	objAppname.value = ar[1];
}

function IsName(str)
{
	var i;

	if (str == "")
		return false;

	/* allow: a-z, A-Z, 0-9, ����, _, |, =, @, . - */
	if(!new RegExp("^[a-zA-Z0-9\u4e00-\u9fa5\_|=@.-]+$").test(str)){
		return false;
	}

	return true;
}

function AJXS(settings)
{
        var http;
        if (typeof XMLHttpRequest != 'undefined')
                http = new XMLHttpRequest();
        else {
                try {
                        http = new ActiveXObject("Msxml2.XMLHTTP");
                }catch (e) {
                        try {
                                http = new ActiveXObject("Microsoft.XMLHTTP");
                        } catch (e) {return ;}
                }
        }

        http.open(settings.type, settings.url, true);
        http.setRequestHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
        http.setRequestHeader("Cache-Control", "no-cache");
        http.setRequestHeader("Accept-Language", "zh-CN,zh;q=0.8");
        http.setRequestHeader("Content-Type", "text/html; charset=GB2312");

        http.onreadystatechange = function() {
                if (http.readyState == 4) {
                        if (http.status == 200)
                                settings.success(http.responseText);
                        else
                                settings.error(http.status);
                }
        }

        http.send(null);
}

function showProxy(proxyname)
{
	var url;

	if (proxyname == "��Ϸ����" ||
		proxyname == "_L2TP����_" ||
		proxyname == "_iWAN����_") {
		url = "/cgi-bin/App/gamecloud/webmain";
		ShowWindow(url, "", 980, 700);
	}
	else {
		url = "/cgi-bin/Monitor/proxy_show?proxyname=" + proxyname;
		ShowWindow(url, "", 840, 700);
	}
}

function showIf(ifname)
{
        var url = "/cgi-bin/Monitor/if_show?name=" + ifname;
        ShowWindow(url, "", 720, 700);
}

function showIppxy(name)
{
	var url = "/cgi-bin/Pppoe/pppoedia_show?name=" + name;
	ShowWindow(url, "", 420, 500);
}

function showIpobj(ipaddr)
{
        var url = "/cgi-bin/Monitor/ipview_data?ipaddr=" + ipaddr;
        ShowWindow(url, "", 820, 750);
}

function formatBytes(num)
{
        if (num >= 1024 * 1024 * 1024)
                return ((num / (1024 * 1024 * 1024))).toFixed(2) + 'G';
        else
        if (num >= 1024 * 1024)
                return ((num / (1024 * 1024))).toFixed(2) + 'M';
        else
        if (num >= 1024)
                return ((num / 1024)).toFixed(2) + 'K';
        else
                return num;
}

function numberformat(num)
{
        if (num >= 1000000000)
                return ((num / 1000000000)).toFixed(2) + 'G';
        else
        if (num >= 1000000)
                return ((num / 1000000)).toFixed(2) + 'M';
        else
        if (num >= 1000)
                return ((num / 1000)).toFixed(2) + 'K';
        else
                return num;
}

function showDump() {
	var width=500, height=600
	var left = (window.screen.width - width) / 2;
	var top  = (window.screen.height - height) / 2;

	args = "scrollbars=1,toolbar=0,menubar=0,status=0,location=0";
	args += ",top=" + top + ",left=" + left + ",height=" + height + ",width=" + width;
	return window.open("/cgi-bin/Monitor/showdump", "_blank", args);
}

function alert_err(msg)
{
	layer.alert(msg, {
		"icon":2, 
		"anim":6, 
		"btn": ['OK'],
		"title": "Error",
		"shade":["0.0", "#ffffff"]
	});
}

function alert_tips(msg)
{
	layer.alert(msg, {
		"icon":0, 
		"anim":0, 
		"btn": ['OK'],
		"title": "Tips",
		"shade":["0.0", "#ffffff"]
	});
}

function alert_ok(msg)
{
	layer.alert(msg, {
		"icon":1, 
		"anim":0, 
		"btn": ['OK'],
		"title": "Success",
		"shade":["0.0", "#ffffff"]
	});
}